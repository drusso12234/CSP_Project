package scheduler;

/**
 * A stub for your secondScheduler1.java scheduler code
 */
public class Scheduler2 implements Scheduler {

	/**
	 * @see scheduler.Scheduler#authors()
	 */
	public String authors() {
		// TODO Your Code Here!
		return null;
	}

	/**
	 * @see scheduler.Scheduler#schedule(scheduler.SchedulingProblem)
	 */
	public ScheduleChoice[] schedule(SchedulingProblem pProblem) {
		// TODO Your Code Here!
		return null;
	}

}
