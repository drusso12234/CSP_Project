package scheduler;

/**
 * A stub for your first scheduler code
 */
public class Scheduler1 implements Scheduler {

	/**
	 * @see scheduler.Scheduler#authors()
	 */
	public String authors() {
		// TODO Your Code Here!
		return null;
	}

	/**
	 * @see scheduler.Scheduler#schedule(scheduler.SchedulingProblem)
	 */
	public ScheduleChoice[] schedule(SchedulingProblem pProblem) {
		// TODO Your Code Here!
		return null;
	}
}
